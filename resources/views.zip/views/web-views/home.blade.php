{{-- @extends('web-views.layout') --}}
@extends('layouts.front-end.app')
@section('css_section')
    <style>
        .slider-icon-1-prev{
            border-radius:10px !important;
        }
        .slider-icon-1-next{
            border-radius:10px !important;
        }
        .pt-50{
            padding-top:50px !important;
        }
        #playButton{
            position: absolute;
            left: 50%;
            right: 50%;
            margin-top:15%;
            cursor: pointer;
        }
    </style>
@stop
@section('content')
    <div class="slider-area bg-gray-8">
        <div class="container-fluid">
            <div class="hero-slider-active-2 nav-style-1 nav-style-1-modify-2 nav-style-1-blue">
                <div class="single-hero-slider single-hero-slider-hm9 single-animation-wrap">
                    <div class="row slider-animated-1">
                        <div class="col-lg-12 col-md-12 col-112 col-sm-12">
                            <!-- <div class="hm9-hero-slider-img">
                                <img class="animated" src="{{asset('public/assets_ui')}}/images/slider/Cherokee-Cotton.jpg" alt="">
                            </div> -->
                            <div class="">
                                <img class="animated" src="{{asset('public/assets_ui')}}/images/slider/Cherokee-Cotton.jpg" style="width:100%;height:auto;" alt="">
                            </div>

                        </div>
                    </div>
                </div>
                <div class="single-hero-slider single-hero-slider-hm9 single-animation-wrap">
                    <div class="row slider-animated-1">
                        <!-- <div class="col-lg-5 col-md-5 col-12 col-sm-6">
                            <div class="hero-slider-content-6 slider-content-hm9">
                                <h5 class="animated">New Arrivals</h5>
                                <h1 class="animated">Home Secure <br>camera</h1>
                                <p class="animated">Prodctect your house with home secure wifi camere indoor/outdoor</p>
                                <div class="btn-style-1">
                                    <a class="animated btn-1-padding-4 btn-1-blue btn-1-font-14" href="">Explore Now</a>
                                </div>
                            </div>
                        </div> -->
                        <div class="col-lg-12 col-md-12 col-112 col-sm-12">
                            <!-- <div class="hm9-hero-slider-img">
                                <img class="animated" src="{{asset('public/assets_ui')}}/images/slider/Cherokee-Cotton.jpg" alt="">
                            </div> -->
                            <div class="">
                                <img class="animated" src="{{asset('public/assets_ui')}}/images/slider/Printed.jpg" style="width:100%;height:auto;" alt="">
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="about-us-area pt-60 pb-50">
        <div class="container">
            <div class="about-us-content-3 text-center">
                <h3>Welcome To <span>New-Design</span> - one stop marketplace ecommerce</h3>
                <p>We have over 50K+ products different adaptive your purpose shopping </p>
            </div>
        </div>
    </div>

    <div class="product-area pt-50 pb-80">
        <div class="container-fluid">
            <div class="tab-content jump">
                <div id="product-1" class="tab-pane active" role="tabpanel">
                    <div class="row">
                        @foreach($categories as $ca)
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6">
                            <div class="single-product-wrap mb-35">
                                <div class="product-img product-img-zoom mb-15">
                                    <a href="{{route('shoplist')}}">
                                        <img src="{{asset('storage/app/public/category/'.$ca->icon)}}" alt="" height="450px">
                                    </a>
                                </div>
                            </div>
                        </div>
                        @endforeach

                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="deal-area">
            <div class="container">
                <div class="deal-bg-color">
                    <div class="row align-items-center">
                        <div class="col-lg-4 col-md-6">
                            <div class="deal-content-2 pl-50">
                                <span>hot deal</span>
                                <h2>
                                    <span>50% SALE OFF</span> T-shirt
                                </h2>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="deal-content-2 pl-35">
                                <p>Discover our collection with leather simple backpacks. Less is more never out trend</p>
                                <div class="deal-btn-2">
                                    <a href="">Shop now</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-5 col-md-12">
                            <div class="deal-img">
                                <a href=""><img src="{{asset('public/assets_ui')}}/images/product/product-14-new.png" alt=""></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="container mt-4">
            <div id="playButton">
                <i class="fa-regular fa-circle-play" style="font-size: 300%;color:white;"></i>
            </div>
            <div class="col-12">
                <video width="100%" height="110%" controls>
                    <source src="https://m.media-amazon.com/images/I/D1LH1XhYUIL.mp4" type="video/mp4">
                </video>
            </div>
        </div>

        <div class="subscribe-area pt-115 pb-120 border-bottom-2">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="section-title-2 text-center">
                            <h2><span>FOLLOW</span> US</h2>
                            <p>Get updates by subscribe our weekly newsletter</p>
                            <div class="social-style-1 text-center pt-20">
                                <a href="#"><i class="icon-social-twitter"></i></a>
                                <a href="#"><i class="icon-social-facebook"></i></a>
                                <a href="#"><i class="icon-social-instagram"></i></a>
                                <a href="#"><i class="icon-social-youtube"></i></a>
                                <a href="#"><i class="icon-social-pinterest"></i></a>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>


        <div class="service-area">
            <div class="container">
                <div class="service-wrap service-wrap-hm9">
                    <div class="row">
                        <div class="col-lg-3 col-md-6 col-sm-6 col-6 service-border-1">
                            <div class="single-service-wrap mb-30">
                                <div class="service-icon service-icon-blue">
                                    <i class="icon-cursor"></i>
                                </div>
                                <div class="service-content">
                                    <h3>Free Shipping</h3>
                                    <span>Orders over ₹100</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-6 col-6 service-border-1">
                            <div class="single-service-wrap mb-30">
                                <div class="service-icon service-icon-blue">
                                    <i class="icon-reload"></i>
                                </div>
                                <div class="service-content">
                                    <h3>Free Returns</h3>
                                    <span>Within 30 days</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-6 col-6 service-border-1">
                            <div class="single-service-wrap mb-30">
                                <div class="service-icon service-icon-blue">
                                    <i class="icon-lock"></i>
                                </div>
                                <div class="service-content">
                                    <h3>100% Secure</h3>
                                    <span>Payment Online</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-6 col-6">
                            <div class="single-service-wrap mb-30">
                                <div class="service-icon service-icon-blue">
                                    <i class="icon-tag"></i>
                                </div>
                                <div class="service-content">
                                    <h3>Best Price</h3>
                                    <span>Guaranteed</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

@stop
