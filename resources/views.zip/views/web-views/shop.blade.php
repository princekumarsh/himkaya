@extends('layouts.front-end.app')
@section('css_section')

@stop
@section('content')
    <div class="">
        <div class="container-fluid">
            <div class="">
                <img class="animated" src="/assets/images/slider/tees.jpg" style="width:100%;height:auto;" alt="">
            </div>
        </div>
    </div>

    <div class="shop-area pb-50 pt-50">
        <div class="container">
            <div class="row flex-row-reverse">
                <div class="col-lg-12">

                    <div class="shop-bottom-area">
                        <div class="tab-content jump">
                            <div id="" class="tab-pane active" role="tabpanel">
                                <div class="row">
                                    @foreach ($topRated as $t)
                                        
                                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-12">
                                        <div class="single-product-wrap mb-35">
                                            <div class="product-img product-img-zoom mb-15">
                                                <a href="#">
                                                    <img src="{{asset('storage/app/public/product/thumbnail/'.$t->thumbnail)}}" alt="" height="296px">
                                                </a>
                                                <div class="product-action-2 tooltip-style-2">
                                                    <button onclick="window.location='{{ url('/wishlist') }}'" title="Wishlist"><i class="icon-heart"></i></button>
                                                    <button title="Quick View" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="icon-size-fullscreen icons"></i></button>
                                                    <button title="Compare"><i class="icon-refresh"></i></button>
                                                </div>
                                            </div>
                                            <div class="product-content-wrap-2 text-center">
                                                <div class="product-rating-wrap">
                                                    <div class="product-rating">
                                                        <i class="icon_star"></i>
                                                        <i class="icon_star"></i>
                                                        <i class="icon_star"></i>
                                                        <i class="icon_star"></i>
                                                        <i class="icon_star gray"></i>
                                                    </div>
                                                    <span>(2)</span>
                                                </div>
                                                <h3><a href="#">{{$t->name}}</a></h3>
                                                <div class="product-price-2">
                                                    <span>₹{{$t->unit_price}}</span>
                                                </div>
                                            </div>
                                            <div class="product-content-wrap-2 product-content-position text-center">
                                                <div class="product-rating-wrap">
                                                    <div class="product-rating">
                                                        <i class="icon_star"></i>
                                                        <i class="icon_star"></i>
                                                        <i class="icon_star"></i>
                                                        <i class="icon_star"></i>
                                                        <i class="icon_star gray"></i>
                                                    </div>
                                                    <span>(2)</span>
                                                </div>
                                                <h3><a href="#">{{$t->name}}</a></h3>
                                                <div class="product-price-2">
                                                    <span>₹{{$t->unit_price}}</span>
                                                </div>
                                                <div class="pro-add-to-cart">
                                                    <button onclick="window.location='{{ url('/product-details') }}'" title="Add to Cart">Add To Cart</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    @endforeach
                                </div>
                            </div>

                        </div>
                        <div class="pro-pagination-style text-center mt-10 pb-50">
                            <ul>
                                <li><a class="prev" href="#"><i class="icon-arrow-left"></i></a></li>
                                <li><a class="active" href="#">1</a></li>
                                <li><a href="#">2</a></li>
                                <li><a class="next" href="#"><i class="icon-arrow-right"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop
