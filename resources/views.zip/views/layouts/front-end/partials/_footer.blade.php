<footer class="footer-area footer-area-cus">
    <div class="container-fluid bg-37475a cus-b-t-top">
        <div class="row">
            <div class="col-md-12">
                <div class="text-center"><h6> Back To Top</h6></div>
            </div>
        </div>
    </div>
    <div class="footer-top border-bottom-4 pb-55 pt-50">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-6">
                    <div class="footer-widget mb-40">
                    <div class="logo">
                        <a href="/"><img src="{{asset('public/assets_ui')}}/images/logo/logo-new.png" alt="logo" style="width:50%"></a>
                    </div>
                        <div class="footer-info-list ">
                            <p class="text-white">The table below shows the Free Font Awesome 5 Audio & Video icons</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-6">
                    <div class="footer-widget ml-70 mb-40">
                        <h3 class="footer-title">Special</h3>
                        <div class="footer-info-list">
                            <ul>
                                <li><a href="wishlist">Featured  Products</a></li>
                                <li><a href="wishlist">Latest Products</a></li>
                                <li><a href="wishlist">Best Selling Products</a></li>
                                <li><a href="wishlist">Top Rated Products</a></li>
                                
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-6">
                    <div class="footer-widget ml-70 mb-40">
                        <h3 class="footer-title">ACCOUNT & SHIPPING INFO</h3>
                        <div class="footer-info-list">
                            <ul>
                                <li><a href="wishlist">Profile Info</a></li>
                                <li><a href="wishlist">Wish Lish</a></li>
                                <li><a href="wishlist">Track Order</a></li>
                                <li><a href="wishlist">Refund Policy</a></li>
                                <li><a href="wishlist">Return Policy</a></li>
                                <li><a href="wishlist">Cancellation policy</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-6">
                    <div class="footer-widget ml-70 mb-40">
                        <h3 class="footer-title">Address</h3>
                        <div class="footer-info-list">
                            <p class="text-white">Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                                 Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
                            </p>
                        </div>
                    </div>
                </div>
              
            </div>
        </div>
    </div>
    <div class="footer-bottom pt-30 pb-30 ">
        <div class="container">
            <div class="row flex-row-reverse">
                <div class="col-lg-6 col-md-6">
                    <div class="payment-img payment-img-right">
                        <a href="#"><img src="{{asset('public/assets_ui')}}/images/icon-img/payment.png" alt=""></a>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="copyright copyright-center">
                        <p>Copyright © 2023 | </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>