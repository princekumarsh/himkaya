<header class="header-area">
@php
    $categories = App\Model\Category::where(['position'=> 0,'home_status'=> 1])->priority()->take(11)->get();
    $brands =    App\Model\Brand::active()->take(15)->get();
@endphp
    <div class="header-large-device">

        <div class="header-middle header-middle-padding-2">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-xl-1 col-lg-1">
                        <div class="logo">

                            @foreach ($brands as $b)
                            <a href="/"><img src="{{asset('storage/app/public/brand/'.$b->image)}}" alt="logo"></a>

                            @endforeach
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-2">
                        <div class="hotline-2-wrap">
                            <div class="hotline-2-icon">
                                <i style="color:#fff;" class="fa fa-map-marker"></i>
                            </div>
                            <div class="hotline-2-content">
                                <span>Hello</span>
                                <h6>Select Your Address</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6">
                        <div class="categori-search-wrap categori-search-wrap-modify-3">
                            <div class="categori-style-1">
                                <select class="nice-select nice-select-style-1">
                                    <option>All</option>
                                    <option>Clothing </option>
                                    <option>T-Shirt</option>
                                    <option>Shoes</option>
                                    <option>Jeans</option>
                                </select>
                            </div>
                            <div class="search-wrap-3">
                                <form action="#">
                                    <input placeholder="Search Products..." type="text">
                                    <button class="blue"><i class="lnr lnr-magnifier"></i></button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-1 col-lg-1">
                        <div class="hotline-2-wrap">
                            <div class="hotline-2-content">
                                <a href="/login"><span>Hello,Sign in</span></a>
                                <h6>Account</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-1 col-lg-1">
                        <div class="hotline-2-wrap">
                            <div class="hotline-2-content">
                                <span>Return</span>
                                <h6>& Order</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-1 col-lg-1">

                        <div class="hotline-2-wrap ">

                                <div class="hotline-2-icon">
                                    <i style="color:#fff;" class="fa fa-shopping-cart" ></i>
                                </div>
                                <div class="hotline-2-content header-cart">
                                <a class="cart-active" href="#"> <h6>Cart</h6>
                                    <span class="cus-pro-count-red"> 02</span> </a>
                                </div>


                        </div>

                    </div>

                </div>
            </div>
        </div>
        <div class="header-bottom bg-blue">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-lg-1">
                        <div class="main-categori-wrap main-categori-wrap-modify-2">
                            <a class="categori-show categori-blue" href="#"><i class="fa fa-list cus-all-i"></i> All </a>
                            <div class="category-menu-2 category-menu-2-blue categori-hide categori-not-visible-2">
                                <nav>
                                    <ul>
                                        <li><a href="#"><i class="icon-energy"></i>HOME</a></li>
                                        @foreach($categories as $ca)
                                        <li><a href=""><i class="icon-energy"></i>{{$ca->name}}</a></li>
                                        @endforeach
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="main-menu main-menu-white main-menu-padding-1 main-menu-font-size-14 main-menu-lh-5">
                            <nav>
                                <ul>
                                    <li><a href="#">HOME</li>
                                    @foreach($categories as $c)
                                    <li><a href="/">{{$c->name}}</a></li>
                                    @endforeach
                                </ul>

                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="header-small-device small-device-ptb-1">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-5">
                    <div class="mobile-logo">
                        <a href="/">
                            <img alt="" width="70" src="{{asset('public/assets_ui')}}/images/logo/logo-new.png">
                        </a>
                    </div>
                </div>
                <div class="col-7">
                    <div class="header-action header-action-flex">
                        <div class="same-style-2 same-style-2-font-inc">
                            <a href="login-register"><i class="icon-user"></i></a>
                        </div>
                        <div class="same-style-2 same-style-2-font-inc">
                            <a href="wishlist"><i class="icon-heart"></i><span class="pro-count red">03</span></a>
                        </div>
                        <div class="same-style-2 same-style-2-font-inc header-cart">
                            <a class="cart-active" href="#">
                                <i class="icon-basket-loaded"></i><span class="pro-count red">02</span>
                            </a>
                        </div>
                        <div class="same-style-2 main-menu-icon">
                            <a class="mobile-header-button-active" href="#"><i class="icon-menu"></i> </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- mobile header start -->
<div class="mobile-header-active mobile-header-wrapper-style">
    <div class="clickalbe-sidebar-wrap">
        <a class="sidebar-close"><i class="icon_close"></i></a>
        <div class="mobile-header-content-area">
            <div class="header-offer-wrap-2 mrg-none mobile-header-padding-border-4">
                <p><span>FREE SHIPPING</span> world wide for all orders over ₹199</p>
            </div>
            <div class="mobile-search mobile-header-padding-border-1">
                <form class="search-form" action="#">
                    <input type="text" placeholder="Search here…">
                    <button class="button-search"><i class="icon-magnifier"></i></button>
                </form>
            </div>
            <div class="mobile-menu-wrap mobile-header-padding-border-2">
                <!-- mobile menu start -->
                <nav>
                    <ul class="mobile-menu">
                        <li class="menu-item-has-children"><a href="">Home</a> </li>
                        <li><a href="#">Best Seller </a></li>
                                    <li><a href="#">Customer Services</a> </li>
                                    <li><a href="#">Today's Deals</a></li>
                                    <li><a href="#">fashhion</a></li>
                                    <li><a href="/category">Category</a></li>
                    </ul>
                </nav>
                <!-- mobile menu end -->
            </div>
            <div class="main-categori-wrap mobile-menu-wrap mobile-header-padding-border-3">
                <a class="categori-show blue" href="#">
                    <i class="lnr lnr-menu"></i> All Department <i class="icon-arrow-down icon-right"></i>
                </a>
                <div class="categori-hide-2">
                    <nav>
                        <ul class="mobile-menu">
                            <li><a href=""><i class="icon-energy"></i> Consumer Electric </a></li>
                            <li><a href=""><i class="icon-handbag"></i> Clothing & Apparel </a></li>
                            <li><a href=""><i class="icon-home"></i> Home, Garden & Kitchen </a></li>
                            <li><a href=""><i class="icon-game-controller"></i> Game Console </a></li>
                            <li><a href=""><i class="icon-eyeglass"></i> Jewelry & Watches </a></li>
                            <li><a href=""><i class="icon-screen-desktop"></i> Computers & Technologies </a></li>
                            <li><a href=""><i class="icon-camera"></i> Camera, Video & Audio </a></li>
                            <li><a href=""><i class="icon-social-dribbble"></i> Sport & Outdoor </a></li>
                            <li><a href=""><i class="icon-screen-smartphone"></i> Phones & Accessories </a></li>
                            <li><a href=""><i class="icon-notebook"></i> Books & Office </a></li>
                            <li><a href=""><i class="icon-rocket"></i> Cars & Motocycles </a></li>
                        </ul>
                    </nav>
                </div>
            </div>
            <div class="mobile-header-info-wrap mobile-header-padding-border-3">
                <div class="single-mobile-header-info">
                    <a href="order-tracking"><i class="lastudioicon-pin-3-2"></i>Track Orders </a>
                </div>

            </div>
            <div class="mobile-contact-info mobile-header-padding-border-4">
                <ul>
                    <li><i class="icon-phone "></i> +91 9874562154</li>
                    <li><i class="icon-envelope-open "></i>Demo@demo.com</li>
                    <li><i class="icon-home"></i> Demo Box Demo Colins Demo West Demo</li>
                </ul>
            </div>
            <div class="mobile-social-icon">
                <a class="facebook" href="#"><i class="icon-social-facebook"></i></a>
                <a class="twitter" href="#"><i class="icon-social-twitter"></i></a>
                <a class="pinterest" href="#"><i class="icon-social-pinterest"></i></a>
                <a class="instagram" href="#"><i class="icon-social-instagram"></i></a>
            </div>
        </div>
    </div>
</div>
<!-- mini cart start -->
<div class="sidebar-cart-active">
    <div class="sidebar-cart-all">
        <a class="cart-close" href="#"><i class="icon_close"></i></a>
        <div class="cart-content">
            <h3>Shopping Cart</h3>
            <ul>
                <li class="single-product-cart">
                    <div class="cart-img">
                        <a href="#"><img src="{{asset('public/assets_ui')}}/images/cart/cart-1.jpg" alt=""></a>
                    </div>
                    <div class="cart-title">
                        <h4><a href="#">Simple Black T-Shirt</a></h4>
                        <span> 1 × ₹49.00	</span>
                    </div>
                    <div class="cart-delete">
                        <a href="#">×</a>
                    </div>
                </li>
                <li class="single-product-cart">
                    <div class="cart-img">
                        <a href="#"><img src="{{asset('public/assets_ui')}}/images/cart/cart-2.jpg" alt=""></a>
                    </div>
                    <div class="cart-title">
                        <h4><a href="#">Norda Backpack</a></h4>
                        <span> 1 × ₹49.00	</span>
                    </div>
                    <div class="cart-delete">
                        <a href="#">×</a>
                    </div>
                </li>
            </ul>
            <div class="cart-total">
                <h4>Subtotal: <span>₹170.00</span></h4>
            </div>
            <div class="cart-checkout-btn">
                <a class="btn-hover cart-btn-style" href="cart">view cart</a>
                <a class="no-mrg btn-hover cart-btn-style" href="checkout">checkout</a>
            </div>
        </div>
    </div>
</div>
